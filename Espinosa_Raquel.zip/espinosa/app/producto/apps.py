from django.apps import AppConfig


class ProductoConfig(AppConfig):
    name = 'producto'
