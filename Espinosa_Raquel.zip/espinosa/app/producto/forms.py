from django import forms
from app.modelo.models import Producto

class FormularioProducto(forms.ModelForm):
	class Meta:
		model = Producto
		fields = ["nombre", "precio", "color", "marca", "fechaElaboracion", "cantidad_Stock"]
