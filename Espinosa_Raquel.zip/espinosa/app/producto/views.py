from django.shortcuts import render, redirect

from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from app.modelo.models import Producto
from .forms import FormularioProducto

@login_required


def principal(request):
	lista = Producto.objects.all()
	context = {
		'lista':lista,
	}
	return render(request, 'producto/principal_producto.html', context)


def crear(request):
	
	formulario = FormularioProducto(request.POST)
	if request.method == 'POST':
		if formulario.is_valid():
			
			datos = formulario.cleaned_data
			producto = Producto()
			producto.nombre = datos.get('nombre')
			producto.precio = datos.get('precio')
			producto.color = datos.get('color')
			producto.marca = datos.get('marca')
			producto.fechaElaboracion = datos.get('fechaElaboracion')
			producto.cantidad_Stock = datos.get('cantidad_Stock')
			producto.save()
			return redirect(principal)


	context = {
		'f': formulario

	}
	return render(request, 'producto/crear_producto.html', context)


def listar(request):

 	return HttpResponse('Es la interfaz de listar un cliente')
