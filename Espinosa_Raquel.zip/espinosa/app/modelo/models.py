from django.db import models

from django.contrib.auth import get_user_model
from django.core.validators import MaxValueValidator

class Producto(models.Model):
	

	nombre = models.CharField('Nombre', max_length = 50)
	precio = models.CharField('Precio ', max_length = 25,blank=False, null=False)
	color = models.CharField('Color ', max_length = 25)
	marca = models.CharField('Marca', max_length = 25, blank=False, null=False)
	fechaElaboracion = models.CharField('fechaElaboracion ', max_length = 25)
	cantidad_Stock = models.CharField('Cantidad Stock', max_length = 25)
	