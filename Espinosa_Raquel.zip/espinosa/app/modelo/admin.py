from django.contrib import admin

from .models import Producto

class AdminProducto(admin.ModelAdmin):
	list_display = ["nombre", "precio", "color", "marca", "fechaElaboracion", "cantidad_Stock"]
	list_editable = ["precio", "color"]
	list_filter = ["nombre"]
	search_fields = ["nombre", "color", "marca"]

	class Meta:
		model = Producto

admin.site.register(Producto,AdminProducto)